// 1. Your calculator is going to contain functions for all of the basic math operators you typically find on simple calculators,
// so start by creating functions for the following items and testing them in your browser’s console.
//     add
//     subtract
//     multiply
//     divide
// 2. Create a new function operate that takes an operator and 2 numbers and then calls one of the above functions on the numbers.
// 3. Create a basic HTML calculator with buttons for each digit, each of the above functions and an “Equals” key.

//     Do not worry about wiring up the JS just yet.
//     There should also be a display for the calculator, go ahead and fill it with some dummy numbers so you can get it looking right.
//     Add a “clear” button.

// 4. Create the functions that populate the display when you click the number buttons… you should be storing the ‘display value’ in a variable somewhere for use in the next step.
// 5. Make the calculator work! You’ll need to store the first number that is input into the calculator when a user presses an operator, and also save which operation has been chosen and then operate() on them when the user presses the “=” key.

//     You should already have the code that can populate the display, so once operate() has been called, update the display with the ‘solution’ to the operation.
//     This is the hardest part of the project. You need to figure out how to store all the values and call the operate function with them. Don’t feel bad if it takes you a while to figure out the logic.

// 6. Gotchas: watch out for and fix these bugs if they show up in your code:

//     Users should be able to string together several operations and get the right answer, with each pair of numbers being evaluated at a time. For example, 12 + 7 - 5 * 3 = should yield 42. An example of the behavior we’re looking for would be this student solution.

// Your calculator should not evaluate more than a single pair of numbers at a time. Example: you press a number button (12), followed by an operator button (+), a second number button (7), and finally a second operator button (-). Your calculator should then do the following: first, evaluate the first pair of numbers (12 + 7), second, display the result of that calculation (19), and finally, use that result (19) as the first number in your new calculation, along with the next operator (-).
// You should round answers with long decimals so that they don’t overflow the screen.
// Pressing = before entering all of the numbers or an operator could cause problems!
// Pressing “clear” should wipe out any existing data.. make sure the user is really starting fresh after pressing “clear”
// Display a snarky error message if the user tries to divide by 0… don’t let it crash your calculator!


// const inputField = document.body.querySelector(".src-input")

// inputField.addEventListener("click", (e) => {
//     window.alert("Input field works! :) ")
// })

const evalFunction = () => {
    sum = eval(srcOfInput.innerText);
    console.log(sum)
    srcOfInput.innerText = sum;
}

let srcOfInput = document.body.querySelector('.input-field');


const eraseButton = document.body.querySelector('#erase-button')
eraseButton.addEventListener('click', (e) => {
    console.log("erasebutton");
    srcOfInput.innerText = "";
})

const posiNegative = document.body.querySelector('#positive-negative')
posiNegative.addEventListener('click', (e) => {
    console.log('positive / negative button clicked')
    srcOfInput.innerText = '-' + srcOfInput.innerText;
})

const percentage = document.body.querySelector('#percentage');
percentage.addEventListener('click', (e) => {
    srcOfInput.innerText *= 100
    srcOfInput.innerText += '%'
})

const noZero = document.body.querySelector('#zero');
noZero.addEventListener('click', (e) => {
    console.log("zero");
    srcOfInput.innerText += 0;
})

const noOne = document.body.querySelector('#one');
noOne.addEventListener('click', (e) => {
    console.log("one");
    srcOfInput.innerText += "1";
})

const noTwo = document.body.querySelector('#two');
noTwo.addEventListener('click', (e) => {
    console.log("two");
    srcOfInput.innerText += "2";
})

const noThree = document.body.querySelector('#three');
noThree.addEventListener('click', (e) => {
    console.log("three");
    srcOfInput.innerText += "3";
})

const noFour = document.body.querySelector('#four');
noFour.addEventListener('click', (e) => {
    console.log("four");
    srcOfInput.innerText += "4";
})

const noFive = document.body.querySelector('#five');
noFive.addEventListener('click', (e) => {
    console.log("five");
    srcOfInput.innerText += "5";
})

const noSix = document.body.querySelector('#six');
noSix.addEventListener('click', (e) => {
    console.log('six');
    srcOfInput.innerText += "6";
})

const noSeven = document.body.querySelector('#seven');
noSeven.addEventListener('click', (e) => {
    console.log("seven");
    srcOfInput.innerText += "7";
})

const noEight = document.body.querySelector('#eight');
noEight.addEventListener('click', (e) => {
    console.log("eight")
    srcOfInput.innerText += "8"
})

const noNine = document.body.querySelector('#nine');
noNine.addEventListener('click', (e) => {
    console.log("nine")
    srcOfInput.innerText += "9"
})

const addButton = document.body.querySelector('#addition');
addButton.addEventListener('click', (e) => {
    console.log("addition")
    srcOfInput.innerText += "+"
})

// multiply

const multiplyButton = document.body.querySelector('#multiply');
multiplyButton.addEventListener('click', (e) => {
    console.log("multiply")
    srcOfInput.innerText += "*"
})

const divideButton = document.body.querySelector('#divide-by');
divideButton.addEventListener('click', (e)=> {
    console.log("divide");
    srcOfInput.innerText += '/'  
})

const dotButton = document.body.querySelector('#dot');
dotButton.addEventListener('click', (e) => {
    console.log('dot');
    srcOfInput.innerText += '.'
})

const equalsButton = document.body.querySelector('#equals');
equalsButton.addEventListener('click', (e) => {
    console.log("equals")
    return evalFunction()
})

function addition(a, b) {
    return a + b;
}

function subtraction(a, b) {
    return a - b;
}

function muliply(a, b) {
    return a * b;
}

function divide(a, b) {
    return a / b
}